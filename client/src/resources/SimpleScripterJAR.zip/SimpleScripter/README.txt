Thank you for downloading the .jar version of SimpleScripter.

This readme is to inform you that SimpleScripter.jar should be kept
in the same directory as the 'icons' folder, otherwise the icons
will not render in the program.

Similarly, ensure config.txt is in the same directory.

Enjoy!
~ Nathan Raymant